export default function calc() {

}