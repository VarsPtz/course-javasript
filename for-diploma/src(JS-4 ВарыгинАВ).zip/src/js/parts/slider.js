export default function slider() {
    
}