export default function timer() {
    
}